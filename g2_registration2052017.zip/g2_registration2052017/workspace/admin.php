
<!DOCTYPE html>
<html>
    <body>
<a href="monroe.php">Click to view all the people from monroe</a>

<form method="post" action="index.php">

            <input type="submit" value="Exit"/>
        </form>
        </body>
</html>
